``cassandra.cqlengine.connection`` - Connection management for cqlengine
========================================================================

.. module:: cassandra.cqlengine.connection

.. autofunction:: default

.. autofunction:: set_session

.. autofunction:: setup
