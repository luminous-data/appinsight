``cassandra.decoder`` - Data Return Formats
===========================================

.. module:: cassandra.decoder

.. function:: tuple_factory

    **Deprecated in 2.0.0.** Use :meth:`cassandra.query.tuple_factory`

.. function:: named_tuple_factory

    **Deprecated in 2.0.0.** Use :meth:`cassandra.query.named_tuple_factory`

.. function:: dict_factory

    **Deprecated in 2.0.0.** Use :meth:`cassandra.query.dict_factory`

.. function:: ordered_dict_factory

    **Deprecated in 2.0.0.** Use :meth:`cassandra.query.ordered_dict_factory`
