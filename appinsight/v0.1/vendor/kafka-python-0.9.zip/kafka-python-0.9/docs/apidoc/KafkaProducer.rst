KafkaProducer
=============

<unreleased> See :class:`kafka.producer.SimpleProducer`
