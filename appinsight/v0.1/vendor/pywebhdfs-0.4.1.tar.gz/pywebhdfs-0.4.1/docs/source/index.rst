.. pywebhdfs documentation master file, created by
   sphinx-quickstart on Mon Jun 10 10:20:37 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

pywebhdfs 0.2.3 documentation
=====================================

Contents:

 .. toctree::
    :maxdepth: 2
 .. autoclass:: pywebhdfs.webhdfs.PyWebHdfsClient
    :members:  __init__, create_file, append_file, read_file, make_dir, rename_file_dir, delete_file_dir, get_file_dir_status, get_file_checksum, list_dir
